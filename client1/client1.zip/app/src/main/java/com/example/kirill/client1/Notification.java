package com.example.kirill.client1;

public class Notification {
    public String title;
    public String author;
    public String description;

    public Notification(String title, String author, String description) {
        this.title = title;
        this.author = author;
        this.description = description;
    }
}
