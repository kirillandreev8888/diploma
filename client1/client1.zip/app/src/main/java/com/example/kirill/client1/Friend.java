package com.example.kirill.client1;

public class Friend {
    public String name;
    public String permission;

    public Friend(String name, String permission) {
        this.name = name;
        this.permission = permission;
    }
}
