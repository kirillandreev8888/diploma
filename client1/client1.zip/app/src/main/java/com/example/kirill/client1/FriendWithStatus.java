package com.example.kirill.client1;

public class FriendWithStatus {
    public String name;
    public String permission;
    public boolean isOnline;

    public FriendWithStatus(String name, String permission, boolean isOnline) {
        this.name = name;
        this.permission = permission;
        this.isOnline = isOnline;
    }
}
