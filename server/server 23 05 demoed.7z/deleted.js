const ip = '192.168.1.66'

var express = require('express')
var socket = require('socket.io')
var MongoClient = require('mongodb').MongoClient
 
var app = express()
var db

app.get("/", function(request, response){

	response.send(
		"<h1>Заголовок</h1> <a href=\"http://"+ip+":3000/page1\"> Страница 1 </a>")
}) 

app.get("/page1", function(request, response){

	response.send("<h1> Страница 1 </h1>")
})

app.get("/testdb", function(request, response){
	var user = {
		login : '',
		password : ''
	}
	db.collection('users').insert(user, function(err, result){
		if (err) {
			console.log(err);
			return response.sendStatus(500);
		}
		response.send(user)
	})
})

app.get("/newcol", function(request, response){
	var event = {
		year : '2019',
		month : '4',
		day : '12',
		nickname : '',
		author : 'qwe',
		eventname : 'Some else event name',
		eventdesc : 'Some else event description'
	}
	db.collection('events').insert(event, function(err, result){
		if (err) {
			console.log(err);
			return response.sendStatus(500);
		}
		response.send(event)
	})
})

app.get("/testcol", function(request, response){
	db.collection('events').find( { nickname : ""}).toArray(function(err, answer){
			if (err){
				console.log(err)
				return;
			}
			console.log(answer)
			response.send(answer)
		})
	})



app.get("/test", function(request, response){
	var event = {
		name : 'SOME AWESOME EVENT',
		nickname : "",
		author : "qwe",
		date : ""
	}
	event.date = new Date("4/12/2019")
	console.log(JSON.stringify(event))
	})

 //server setup
var server = app.listen(3000, ip, function(){
	console.log('listening to requests on port 3000')

})



